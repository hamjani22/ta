<?php $__env->startSection('content'); ?>
    <!-- Page Heading -->
<h1 class="h3 mb-2 text-gray-800">Tables</h1>
<p class="mb-4">DataTables is a third party plugin that is used to generate the demo table below. For more information about DataTables, please visit the <a target="_blank" href="https://datatables.net">official DataTables documentation</a>.</p>

<!-- DataTales Example -->
<div class="card shadow mb-4">
  <div class="card-header py-3">
    <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>No</th>
            <th>Tanggal</th>
            <th>Suhu</th>
            <th>Kadar Oksigen</th>
            <th>Kadar Ph</th>
            <th>Residu Terlarut</th>
          </tr>
        </thead>
        <tfoot>
          <tr>
            <th>No</th>
            <th>Tanggal</th>
            <th>Suhu</th>
            <th>Kadar Oksigen</th>
            <th>Kadar Ph</th>
            <th>Residu Terlarut</th>
          </tr>
        </tfoot>
        <tbody>
            <?php $__currentLoopData = $irridentify; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->id); ?></td>
                    <td><?php echo e($item->tanggal->format('d F Y h:i:s')); ?></td>
                    <td><?php echo e($item->suhu); ?></td>
                    <td><?php echo e($item->kadar_oksigen); ?></td>
                    <td><?php echo e($item->kadar_ph); ?></td>
                    <td><?php echo e($item->residu_terlarut); ?></td>
                </tr>
                
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Bismillah TA\Irridentify\resources\views/admin/tables.blade.php ENDPATH**/ ?>